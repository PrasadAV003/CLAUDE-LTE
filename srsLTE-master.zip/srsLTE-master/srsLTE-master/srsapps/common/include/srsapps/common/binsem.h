/**
 *
 * \section COPYRIGHT
 *
 * Copyright 2013-2015 The srsLTE Developers. See the
 * COPYRIGHT file at the top-level directory of this distribution.
 *
 * \section LICENSE
 *
 * This file is part of the srsLTE library.
 *
 * srsLTE is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * srsLTE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * A copy of the GNU Affero General Public License can be found in
 * the LICENSE file in the top-level directory of this distribution
 * and at http://www.gnu.org/licenses/.
 *
 */


#include <pthread.h>

#ifndef BINSEM_H
#define BINSEM_H

/** Implementation of a binary semaphore using POSIX condition variable and mutex
 */

namespace srslte {

  class binsem
  {
  public: 
    binsem() {
      pthread_mutex_init(&mutex, NULL);
      pthread_cond_init(&cv, NULL);
      state = true; 
    }
    ~binsem() {
      pthread_mutex_destroy(&mutex);
      pthread_cond_destroy(&cv); 
    }
    void take() {
      pthread_mutex_lock(&mutex);
      while(!state) {
        pthread_cond_wait(&cv, &mutex);        
      }
      state = false;
      pthread_mutex_unlock(&mutex);
    }
    void give() {
      pthread_mutex_lock(&mutex);
      pthread_cond_signal(&cv);
      state = true; 
      pthread_mutex_unlock(&mutex);      
    }
  private:
    pthread_cond_t cv; 
    pthread_mutex_t mutex; 
    bool state; 
  };
}

#endif
